import java.sql.*;
public class Databaseexample {

    public static void main(String[] args) {
        String username ="SidratulTanzilaTasmi";
        String passward ="tasmi138";
        //string for URL
        String url="jdbc:oracle:thin:@localhost:1521/ORCLPDB";
        String sqlQuery="SELECT A_ID , AMOUNT , TYPE FROM TRANSACTIONS";
        int totalRows = 10000;
        //Initialising the variables
        int account;
        int amount;
        int type;
        int totalAccount=0;
        int CIP= 0;
        int VIP = 0;
        int ordinary = 0;
        int uncategorized;
        int[] balance = new int[totalRows];
        int[] total = new int[totalRows];
        int[] accPresent = new int[totalRows];
        for (int i = 0; i < totalRows; ++i) {
            balance[i]=0;
            total[i]=0;
            accPresent[i]=0;
        }

        try{
            //1.We are Registering for the Driver class
            Class.forName("oracle.jdbc.driver.OracleDriver");
            //2. We are creating a connection object here
            Connection con = DriverManager.getConnection(url,username,passward);
            //3. We are creating a statement object here
            Statement statement;
            statement = con.createStatement();
            //4. Showing that the connection to the database system is successful
            System.out.println("Connection to database successful");
            //5. We are creating the query here
            ResultSet result;
            result = statement.executeQuery(sqlQuery);
            while(result.next())
            //6. To retreive by the column name
            {
                account=result.getInt("A_ID");
                amount=result.getInt("AMOUNT");
                type = result.getInt("TYPE");
                if (accPresent[account] == 0) { // if this account has been previously seen or not
                    accPresent[account] = 1;
                    ++totalAccount; // if not then increase count
                }
                total[account] += amount;
                //type 0 and 1 defines if there has been any transaction from the current account balance, which we might withdraw or give
                if(type==0)
                {balance[account]+=amount;}
                else
                {balance[account]-=amount;}
            }
            //After closing the databse system we are traversing the array to count cip,vip an uncatagorized etc number
            //we already calculated totalAccount while traversing through the rows
            for (int i = 1; i <= totalAccount;i++) {
                if (balance[i] > 1000000 && total[i] > 5000000)
                {CIP++;}

                if (balance[i] > 500000 && balance[i] < 900000 && total[i] > 3500000 && total[i] < 4500000)
                {VIP++;}

                if (balance[i] < 40000 && total[i] < 3000000) {
                    ++ordinary;
                }
            }
            uncategorized=totalAccount-CIP-VIP-ordinary;
           //printing out the values
            System.out.println("Total Number of Accounts: " + totalAccount);
            System.out.println("CIP count: " + CIP);
            System.out.println("VIP count: " + VIP);
            System.out.println("Ordinary count: " + ordinary);
            System.out.println("Uncategorized: " + uncategorized);
            //After doing the job we will have to close the db connection
            con.close();
            statement.close();
            result.close();
        }
        //if any exception is there in try, then itll come to this catch statements
        catch(SQLException e)
        {

            System.out.println("Error while connecting to database. Exception code: "+e);
        }
        catch(ClassNotFoundException e)
        {
            System.out.println("Failed to register driver. Exception code: "+e);
        }
        System.out.println("Thank you!");
        //end of database system
    }

}