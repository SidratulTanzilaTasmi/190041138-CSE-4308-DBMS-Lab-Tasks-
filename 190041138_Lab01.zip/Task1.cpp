#include<bits/stdc++.h>
#include<stdio.h>
#include<string.h>
using namespace std;

void writeonfiles(); //program to make two files
void databaseinput();// program to add entry on the database
void showentries();//program to give your id and find detail information
void searchbudget(); //program to search for budget more than 60,000
void replacebudget();//program to change the status of budgets for more than 60,000
int main()
{
    //I have added the options in order to avoid problems like rewriting of data and to check that all my functions work properly
    cout<<"Would you like to make a database?\n1.Yes\n2.No"<<endl;
    int op1;
    cin>>op1;
    if(op1==1)
    {
        writeonfiles();
    }
    cout<<"Would you like to give database entry?"<<endl<<"1.Yes\n2.No"<<endl;
    int op2;
    cin>>op2;
    if(op2==1)
    {
        databaseinput();
    }

    cout<<"Would you like to search ID?\n1.Yes\n2.No"<<endl;
    int op3;
    cin>>op3;
    if(op3==1)
    {
        cout<<"Enter ID: ";
        showentries();
    }
    cout<<"Would you like to search budget?\n1.Yes\n2.No"<<endl;
    int op4;
    cin>>op4;
    if(op4==1)
    {
        searchbudget();
    }

    cout<<"Would you like to replace the status of budget?\n1.Yes\n2.No"<<endl;
    int op5;
    cin>>op5;
    if(op5==1)
    {
        replacebudget();
    }

}
void writeonfiles()
{  //function makes the records for the database, I have not added entry here because if i recall this function , it'll rewrite.
    char sentence[1000]="Employee_ID Name Age Blood group gender projectID team_leader role\n";
    FILE *filelocation;
    filelocation = fopen("Employes.txt", "w");
    if (filelocation == NULL)
    {
        printf("Error!");
        exit(1);
    }
    fprintf(filelocation, "%s", sentence);
    fclose(filelocation);
    strcpy(sentence,"Project_ID Project_Name Employer_Name Estimated_Budget ETA(months) Number_of_employees Status\n");
    filelocation=fopen("Project.txt","w");
    if (filelocation == NULL)
    {
        printf("Error!");
        exit(1);
    }
    fprintf(filelocation, "%s", sentence);
    fclose(filelocation);
}
void databaseinput()
{
  //user can give input to both the type of files, I have used the append mode here.
    FILE *filelocation;
    char filePath[100];
    printf("Enter file to put data entry: \n1.Employees\n2.Project\n");
    int n;
    cin>>n;
    char entry[1000]="\n"; char info[1000];
    if(n==1)
    {

        strcpy(filePath,"Employes.txt");
        cout<<"ID: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Name: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Age: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Blood Group: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Gender: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Project ID: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Team Leader: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Role: "; cin>>info; strcat(entry,info); strcat(entry," ");

    }
    else
    {
        strcpy(filePath,"Project.txt");
        cout<<"Project ID: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Project Name: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Employer Name: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Estimated Budget: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"ETA: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Number of employee: "; cin>>info; strcat(entry,info); strcat(entry," ");
        cout<<"Status: "; cin>>info; strcat(entry,info); strcat(entry," ");
    }
    filelocation = fopen(filePath, "a");
      if (filelocation == NULL)
    {
        printf("Error!");
        exit(1);
    }

    printf("Enter Database entries");
    fflush(stdin);
    fputs(entry, filelocation);
    fclose(filelocation);

}
void showentries()
{

    int id;
    cin>>id;
    char rest[1000];
    FILE *filelocation;
    int idfound=0;
    filelocation=fopen("Employes.txt","r");
    while(fgets(rest,1000,filelocation))

    {
        char *words=strtok(rest," ");
        int idd=atoi(words);

        if(idd==id) //print all the informations if ID is matched
        {
            idfound=1; //to check if ID exists or not

            cout<<"ID: "<<words<<endl;
            words=strtok(NULL," ");
            cout<<"Name: "<<words<<endl;
            words=strtok(NULL," ");
            cout<<"Age: "<<words<<endl;
            words=strtok(NULL," ");
            cout<<"Blood Group: "<<words<<endl;
            words=strtok(NULL," ");
            cout<<"Gender: "<<words<<endl;
            words=strtok(NULL," ");
            cout<<"Project ID: "<<words<<endl;
            words=strtok(NULL," ");
            cout<<"Team Leader: "<<words<<endl;
            words=strtok(NULL," ");
            cout<<"Role: "<<words<<endl;

        }
    }
    if(idfound!=1)
    {
        cout<<"ID does not exist"<<endl;
    }
    fclose(filelocation);
}
void searchbudget()
{
    FILE *filelocation, *filelocation2;
    char entry[1000];
    char budget[1000];
    filelocation=fopen("Project.txt","r");
    filelocation2=fopen("demo.txt","w");
    fprintf(filelocation2,"%s","Project_ID Project_Name Employer_Name Estimated_Budget ETA(months) Number_of_employees Status\n");
    while(fgets(entry,1000,filelocation))
    {
        strcpy(budget,entry);

        char *words=strtok(budget," ");
        int cnt=0;
        while(words!=NULL)
        {
            cnt++;
            if(cnt==4)
            {
                int num=atoi(words); //i convert the string of budget into integer to check my given condition
                if(num>=60000)
                {
                    fprintf(filelocation2, "%s", entry);
                }
            }
            words=strtok(NULL," ");

        }
    } //in order to delete the required entry, i have added rest of the entries into a new file, deleted the previous one and renamed the file as Project
    fclose(filelocation);
    fclose(filelocation2);
    remove("Project.txt");
    rename("demo.txt","Project.txt");
}
void replacebudget()
{
    FILE *filelocation, *filelocation2;
    filelocation=fopen("Project.txt","r");
    filelocation2=fopen("demo.txt","w");
    char entry[1000];
    char budget[1000];
    fgets(entry,1000,filelocation);
    fprintf(filelocation2,"%s",entry);
    while(fgets(entry,1000,filelocation))
    {
        strcpy(budget,entry);

        char *words=strtok(budget," ");

        int cnt=0;
        int num, isbudget=0;
        while(words!=NULL)
        {
            cnt++;
            fprintf(filelocation2,"%s"," ");
            if(cnt<=3 || cnt==5)
            {
                fprintf(filelocation2,"%s",words);
            }
            if(cnt==4)
            {
                num=atoi(words);
                if(num>=60000)
                {
                    isbudget=1;
                }
                fprintf(filelocation2,"%s",words);
            }
            if(cnt==6)
            { //while putting the status into my rewritten file, i check if the budget is over 60,000 through isbudget
                if(isbudget)
                {
                    fprintf(filelocation2,"%s","Ongoing\n");
                }
                else if(isbudget==0)
                {
                    fprintf(filelocation2,"%s","Onhold\n");
                }
            }

            words=strtok(NULL," ");

        }
    }
    //two files have been made to make the rewritten status of all the records
    fclose(filelocation);
    fclose(filelocation2);
    remove("Project.txt");
    rename("demo.txt","Project.txt");
}
